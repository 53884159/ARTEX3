﻿#!/usr/bin/env bash
# ARTEX 安装脚本：① 全部 Docker（本地构建镜像）  ② 本地编译运行
#
# 与上游的区别：不拉 autumn27/artex 预构建镜像，而是用本仓库源码现编。
# 这样 fork / 私有仓库 / 源码包都能一键起，不依赖任何已发布镜像是否存在。
set -euo pipefail
cd "$(cd "$(dirname "$0")" && pwd)"

info(){ printf '\033[36m[*]\033[0m %s\n' "$*"; }
ok(){   printf '\033[32m[+]\033[0m %s\n' "$*"; }
warn(){ printf '\033[33m[!]\033[0m %s\n' "$*"; }
die(){  printf '\033[31m[x]\033[0m %s\n' "$*" >&2; exit 1; }
ask(){  local p="$1" d="${2:-}" a; read -rp "$p${d:+ [$d]}: " a; echo "${a:-$d}"; }
rand(){ head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 24; }

# ── 推断当前仓库的 owner/repo ───────────────────
# 自更新（页面「检查更新」）要按这个地址去 GitHub 找 Releases。
# 优先取 git remote，取不到再问，问不出就留空（更新功能自行禁用，不影响使用）。
detect_repo(){
  local url="" repo=""
  if command -v git >/dev/null 2>&1 && [ -d .git ]; then
    url="$(git remote get-url origin 2>/dev/null || true)"
  fi
  case "$url" in
    *github.com[:/]*)
      repo="${url#*github.com}"
      repo="${repo#[:/]}"
      repo="${repo%.git}"
      # ssh 形式 git@github.com:owner/repo
      repo="${repo##*:}"
      ;;
  esac
  if [ -n "$repo" ]; then
    printf '%s' "$repo"
  fi
}


# ── docker 环境检测 / 自动安装 ───────────────────
ensure_docker(){
  if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
    ok "已检测到 docker 与 docker compose"; return
  fi
  warn "未检测到 docker / docker compose"
  case "$(uname -s)" in
    Linux)
      if [ "$(ask '自动安装 Docker? (y/n)' y)" = y ]; then
        curl -fsSL https://get.docker.com | sh
        sudo usermod -aG docker "$USER" || true
        ok "Docker 安装完成（用户组变更需重新登录后免 sudo）"
      else
        die "请自行安装 docker 后重试"
      fi ;;
    Darwin)
      die "macOS 请安装 Docker Desktop：https://www.docker.com/products/docker-desktop/" ;;
    MINGW*|MSYS*|CYGWIN*)
      die "Windows 请先安装 Docker Desktop 并启用 WSL2 后端：https://www.docker.com/products/docker-desktop/ ，装完在 Git Bash 里重跑本脚本" ;;
    *)      die "请自行安装 docker 后重试" ;;
  esac
}

# ── 写 .env（幂等：已存在则不覆盖，只补缺失的键） ──
set_env(){ # set_env KEY VALUE
  local k="$1" v="$2"
  if grep -q "^${k}=" .env 2>/dev/null; then
    sed -i.bak "s|^${k}=.*|${k}=${v}|" .env && rm -f .env.bak
  else
    printf '%s=%s\n' "$k" "$v" >> .env
  fi
}

write_env(){
  if [ ! -f .env ]; then
    cp .env.example .env
    ok "已从 .env.example 生成 .env"
  else
    info "沿用已存在的 .env（只补齐缺失项）"
  fi

  # Postgres 密码：没设或还是占位值才问
  local cur
  cur="$(grep -m1 '^POSTGRES_PASSWORD=' .env 2>/dev/null | cut -d= -f2- || true)"
  if [ -z "$cur" ] || [ "$cur" = "change-me-please" ]; then
    local pw; pw="$(ask 'Postgres 密码（回车随机生成）' "$(rand)")"
    set_env POSTGRES_PASSWORD "$pw"
    ok "POSTGRES_PASSWORD 已设置"
  fi

  # 自更新仓库地址
  local repo_def repo
  repo_def="$(detect_repo)"
  repo_def="${repo_def:-Autumn-27/artex}"
  repo="$(ask '自更新检查指向的仓库 owner/repo（回车用上面的）' "$repo_def")"
  set_env ARTEX_REPO "$repo"
  ok "ARTEX_REPO=${repo}（页面「检查更新」会走这个仓库的 Releases）"

  # 构建版本号
  local ver
  if command -v git >/dev/null 2>&1 && [ -d .git ]; then
    ver="$(git describe --tags --always --dirty 2>/dev/null || echo local)"
  else
    ver="local"
  fi
  set_env ARTEX_BUILD_VERSION "$ver"
  ok "ARTEX_BUILD_VERSION=${ver}"

  # LLM key（可留空，后续在 UI 配）
  local kcur
  kcur="$(grep -m1 '^ANTHROPIC_API_KEY=' .env 2>/dev/null | cut -d= -f2- || true)"
  if [ -z "$kcur" ]; then
    local key; key="$(ask 'ANTHROPIC_API_KEY（可留空，后续在 UI 配）' '')"
    [ -n "$key" ] && set_env ANTHROPIC_API_KEY "$key"
  fi

  # 走本地构建，不要指向远端镜像
  set_env ARTEX_IMAGE "artex:local"
}

# ── ① 全部 Docker（本地构建） ───────────────────
install_docker(){
  ensure_docker
  write_env

  info "构建镜像（首次会拉基础镜像 + 编前端 + 编 Go，耗时较长，请耐心等）…"
  docker compose build
  ok "镜像构建完成"

  info "启动…"
  docker compose up -d
  ok "启动完成 → http://localhost:8787"
  info "首次进入会自动跳到 /setup 设置管理员密码"
  info "查看日志：docker compose logs -f artex"
  info "重新构建（改了源码后）：docker compose build && docker compose up -d"
}

# ── ② 本地编译运行 ──────────────────────────────
install_local(){
  echo "数据库安装方式："
  echo "  1) 连接已有 PostgreSQL"
  echo "  2) 用 Docker 起一个 PostgreSQL（需要 docker）"
  case "$(ask '选择' 1)" in
    2)
      ensure_docker
      local pw; pw="$(ask 'Postgres 密码（回车随机）' "$(rand)")"
      docker run -d --name artex-pg -p 5432:5432 \
        -e POSTGRES_USER=artex -e POSTGRES_PASSWORD="$pw" -e POSTGRES_DB=artex \
        -v artex-pg:/var/lib/postgresql/data postgres:16-alpine
      DB_HOST=127.0.0.1 DB_PORT=5432 DB_USER=artex DB_PASS="$pw" DB_NAME=artex DB_SSL=disable ;;
    *)
      DB_HOST="$(ask '数据库地址' 127.0.0.1)"
      DB_PORT="$(ask '端口' 5432)"
      DB_USER="$(ask '账号' artex)"
      DB_PASS="$(ask '密码' '')"
      DB_NAME="$(ask '数据库名' artex)"
      DB_SSL="$(ask 'sslmode (disable/require)' disable)" ;;
  esac

  # 生成 config.json
  cat > config.json <<JSON
{
  "database": {
    "host": "${DB_HOST}",
    "port": ${DB_PORT},
    "user": "${DB_USER}",
    "password": "${DB_PASS}",
    "dbname": "${DB_NAME}",
    "sslmode": "${DB_SSL}"
  }
}
JSON
  ok "已生成 config.json"

  # go 环境检查
  command -v go >/dev/null 2>&1 || die "未检测到 Go，请先安装 Go（>=1.26）：https://go.dev/dl/"
  ok "Go: $(go version)"

  # 自更新仓库地址（编进二进制，页面「检查更新」用）
  local repo_def repo
  repo_def="$(detect_repo)"; repo_def="${repo_def:-Autumn-27/artex}"
  repo="$(ask '自更新检查指向的仓库 owner/repo（回车用上面的）' "$repo_def")"
  local ver
  if command -v git >/dev/null 2>&1 && [ -d .git ]; then
    ver="$(git describe --tags --always --dirty 2>/dev/null || echo local)"
  else
    ver="local"
  fi
  local ldflags="-s -w -X main.version=${ver} -X github.com/Autumn-27/artex/selfupdate.Repo=${repo}"

  # 内嵌前端需要 node 出静态产物
  if command -v npm >/dev/null 2>&1; then
    info "构建前端静态产物…"
    ( cd web && npm ci && npm run build:static )
    rm -rf server/webui/dist && cp -r web/out server/webui/dist
    info "编译内嵌单二进制…"
    # shellcheck disable=SC2086
    CGO_ENABLED=0 go build -tags embedui -trimpath -ldflags "${ldflags}" -o artex ./cmd/artex
  else
    warn "未检测到 npm：将编译**不内嵌前端**的后端（前端需另跑 npm run dev）"
    # shellcheck disable=SC2086
    CGO_ENABLED=0 go build -trimpath -ldflags "${ldflags}" -o artex ./cmd/artex
  fi
  ok "编译完成 → ./artex"

  info "启动…（Ctrl-C 退出）"
  ./start.sh
}

echo "=============================="
echo "  ARTEX 安装"
echo "  1) 全部 Docker 安装（本地构建镜像，推荐）"
echo "  2) 本地运行（go 编译）"
echo "=============================="
case "$(ask '选择' 1)" in
  1) install_docker ;;
  2) install_local ;;
  *) die "无效选择" ;;
esac
